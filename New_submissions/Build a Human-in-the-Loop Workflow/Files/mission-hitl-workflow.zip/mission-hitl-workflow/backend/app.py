import os
import json
import re
import uuid
from datetime import datetime, timezone

from dotenv import load_dotenv
load_dotenv()  # Reads the .env file and injects variables into the environment

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from google import genai  # New unified SDK

# =========================
# Gemini configuration
# =========================
# NOTE: the client is created lazily (see get_client()) instead of at
# import time. Building genai.Client() eagerly raises immediately when
# GEMINI_API_KEY is missing, which used to crash the whole server before
# Flask even started. Lazy init lets the app boot without a key and fall
# back to FALLBACK_RESPONSE, same as any other Gemini failure.
_client = None


def get_client():
    global _client
    if _client is None:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY is not set")
        _client = genai.Client(api_key=api_key)
    return _client


api_key_loaded = os.getenv("GEMINI_API_KEY") is not None
print(f"KEY LOADED: {api_key_loaded}")
if not api_key_loaded:
    print("WARNING: GEMINI_API_KEY environment variable is not set! /analyze will use FALLBACK_RESPONSE.")

# =========================
# Flask app
# =========================
app = Flask(__name__)
CORS(app)

# =========================
# Load prompt from file
# =========================
def load_prompt():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    prompt_path = os.path.join(base_dir, "..", "docs", "prompt.txt")

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()

# =========================
# Extract JSON from AI text
# =========================
def extract_json(text):
    fence_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if fence_match:
        return fence_match.group(1)

    match = re.search(r'\{.*?\}', text, re.DOTALL)
    if match:
        return match.group(0)

    return None

# =========================
# Validate AI output schema
# =========================
def validate_ai_output(data):
    required_keys = [
        "classification",
        "severity",
        "recommended_action",
        "reasoning"
    ]

    for key in required_keys:
        if key not in data:
            return False, f"Missing key: {key}"
        if not isinstance(data[key], str):
            return False, f"Invalid type for {key}: expected string"

    return True, None

# -------------------------
# Dev/demo safety switch
# Set to False during development to preserve your daily quota.
# Flip to True only when doing a real demo or final test.
# -------------------------
USE_AI = True

# -------------------------
# Global fallback response
# -------------------------
FALLBACK_RESPONSE = {
    "classification": "undetermined anomaly",
    "severity": "low",
    "recommended_action": "monitor system and perform manual review",
    "reasoning": "Insufficient or inconsistent telemetry data for reliable classification",
    "requires_approval": True
}

# =========================
# Human-in-the-loop: simulated audit log
# =========================
# Every approve/reject decision is appended here as a JSON file on disk.
# This is a *local, simulated* audit trail only — it is not a database
# and it does not connect to any external system.
LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
LOG_FILE = os.path.join(LOG_DIR, "decision_log.json")


def _ensure_log_file():
    os.makedirs(LOG_DIR, exist_ok=True)
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)


def _read_log():
    _ensure_log_file()
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def _write_log(entries):
    _ensure_log_file()
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=2)


# -------------------------
# SIMULATION ONLY
# -------------------------
# This function never sends an email, moves money, fires a thruster,
# or talks to any real spacecraft/ground-station system. It only builds
# a descriptive string so the "Execute action" step of the architecture
# diagram is visible in the demo. Swapping this for a real integration
# (email API, budget system, command uplink) is intentionally left out
# of scope, per the challenge instructions.
# -------------------------
def simulate_action_execution(subsystem, recommended_action):
    templates = {
        "thermal": "Simulated cooling/load adjustment applied.",
        "power": "Simulated power reallocation applied.",
        "communications": "Simulated transmission parameter change applied.",
    }
    detail = templates.get(subsystem, "Simulated mission action applied.")
    return f'{detail} No external system was contacted. (Action: "{recommended_action}")'


# =========================
# Main endpoint — Agent + Analysis + Proposed Action
# =========================
@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()

    if not data:
        return jsonify({"error": "No JSON provided"}), 400

    if "subsystem" not in data:
        return jsonify({"error": "Missing subsystem"}), 400

    if "value" not in data:
        return jsonify({"error": "Missing value"}), 400

    if not USE_AI:
        return jsonify({
            "classification": "thermal anomaly",
            "severity": "medium",
            "recommended_action": "reduce computational load and monitor cooling system",
            "reasoning": "Core temperature of 85°C during nominal phase exceeds the safe operating threshold",
            "requires_approval": True
        }), 200

    try:
        prompt_template = load_prompt()

        final_prompt = f"""
{prompt_template}

Telemetry Input:
{json.dumps(data)}
"""

        response = get_client().models.generate_content(
            model="gemini-2.5-flash",
            contents=final_prompt
        )

        raw_text = response.text.strip() if response.text else ""
        print("\n===== RAW GEMINI RESPONSE =====")
        print(raw_text)
        print("================================\n")

        if not raw_text:
            return jsonify(FALLBACK_RESPONSE), 200

        json_str = extract_json(raw_text)
        print("EXTRACTED JSON:", json_str)

        if not json_str:
            return jsonify(FALLBACK_RESPONSE), 200

        try:
            ai_output = json.loads(json_str)
        except json.JSONDecodeError:
            return jsonify(FALLBACK_RESPONSE), 200

        is_valid, error_msg = validate_ai_output(ai_output)
        if not is_valid:
            print("VALIDATION ERROR:", error_msg)
            return jsonify(FALLBACK_RESPONSE), 200

        ai_output["classification"] = ai_output["classification"].strip().lower()
        ai_output["severity"] = ai_output["severity"].strip().lower()
        ai_output["recommended_action"] = ai_output["recommended_action"].strip()
        ai_output["reasoning"] = ai_output["reasoning"].strip()

        allowed_severity = ["low", "medium", "high", "critical"]
        if ai_output["severity"] not in allowed_severity:
            return jsonify(FALLBACK_RESPONSE), 200

        # The agent never executes anything on its own — every recommended
        # action is a *proposal* that must go through the human approval
        # gate below (/decision).
        ai_output["requires_approval"] = True
        ai_output["subsystem"] = data.get("subsystem")

        return jsonify(ai_output), 200
    except Exception as e:
        print("ERROR:", str(e))
        return jsonify(FALLBACK_RESPONSE), 200


# =========================
# Human approval gate — Approve / Reject → (simulated) Execute
# =========================
@app.route('/decision', methods=['POST'])
def decision():
    """
    Receives the human's decision on a proposed action and either
    "executes" it (simulated) or records the rejection.

    Nothing here sends a real email, spends real money, or touches a
    real external system — see simulate_action_execution() above.
    """
    payload = request.get_json()

    if not payload:
        return jsonify({"error": "No JSON provided"}), 400

    required = ["subsystem", "recommended_action", "decision"]
    missing = [key for key in required if key not in payload]
    if missing:
        return jsonify({"error": f"Missing field(s): {', '.join(missing)}"}), 400

    decision_value = str(payload["decision"]).strip().lower()
    if decision_value not in ("approve", "reject"):
        return jsonify({"error": "decision must be 'approve' or 'reject'"}), 400

    entry = {
        "id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "subsystem": payload.get("subsystem"),
        "classification": payload.get("classification"),
        "severity": payload.get("severity"),
        "recommended_action": payload.get("recommended_action"),
        "reasoning": payload.get("reasoning"),
        "decision": decision_value,
    }

    if decision_value == "approve":
        entry["status"] = "executed"
        entry["system_response"] = simulate_action_execution(
            payload.get("subsystem", "unknown"),
            payload.get("recommended_action", "")
        )
    else:
        entry["status"] = "rejected"
        entry["system_response"] = "Action rejected by human operator. No changes were made."

    log = _read_log()
    log.append(entry)
    _write_log(log)

    return jsonify(entry), 200


# =========================
# Audit trail — every past decision
# =========================
@app.route('/history', methods=['GET'])
def history():
    log = _read_log()
    # Most recent first
    return jsonify(list(reversed(log))), 200


@app.route('/')
def serve_frontend():
    frontend_dir = os.path.join(os.path.dirname(__file__), '..', 'frontend')
    return send_from_directory(frontend_dir, 'index.html')


# =========================
# Run server
# =========================
if __name__ == '__main__':
    app.run(debug=True)
