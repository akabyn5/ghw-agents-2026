# 🛰️ Mission Intelligence Platform — Human-in-the-Loop Workflow

**An extension of the AI Mission Decision Copilot** that adds a mandatory human-approval gate before any AI-recommended action is (safely, simulated) carried out.

The original Copilot analyzes spacecraft telemetry and proposes a decision. This extension inserts a human checkpoint between "the agent proposes" and "the system acts," so no action is ever taken automatically — a person always has the final say.

---

## 📌 Overview

This challenge asked for an agent that operates autonomously but **pauses to ask a human for explicit approval before taking a sensitive action** (e.g. sending an email, spending money, or — in this case — issuing a mission command).

Built on top of the existing platform, it keeps the original AI analysis step untouched and adds three new pieces:

- A **Proposed Action** panel that clearly separates "what the AI suggests" from "what actually happens."
- A **human approval gate** (Approve / Reject) that the workflow cannot bypass.
- A **simulated executor** and an **audit log** that record every decision, so the full loop is auditable.

No email is sent, no money moves, and no real external system is ever contacted. Every "execution" is a canned, clearly-labeled simulation — by design, per the challenge's constraints.

---

## 🏗 Architecture

```
Agent (telemetry input)
        ↓
Analysis (Gemini-based classification)
        ↓
Proposed Action  ──────────────────────────────┐
        ↓                                       │
┌──────────────────────────┐                    │
│ HUMAN APPROVAL REQUIRED   │  ← workflow pauses here
│                           │
│   Approve   /   Reject    │
└────────────┬──────────────┘
             ↓
   Execute action (simulated)
             ↓
      Decision Log (audit trail)
```

```
Frontend (HTML + JS)
        ↓
Flask Backend
        ├── POST /analyze   → Agent + Analysis + Proposed Action
        ├── POST /decision  → Human Approval gate + simulated execution
        └── GET  /history   → Audit trail of every past decision
```

---

## 🧠 How It Works

1. The user selects a telemetry scenario in the frontend (thermal, power, or communications anomaly).
2. The frontend sends the telemetry to `POST /analyze`. The backend calls Gemini, validates the JSON it returns, and sends back a `classification`, `severity`, `recommended_action`, and `reasoning` — this is the agent's **proposal**, nothing more.
3. The UI displays the proposal inside a clearly marked **"⚠ Human Approval Required"** panel. The workflow stops here; nothing is executed yet.
4. The human clicks **Approve** or **Reject**.
   - The frontend sends that decision to `POST /decision`.
   - On **Approve**, the backend runs `simulate_action_execution()`, which returns a descriptive, obviously-simulated confirmation message (no real system is touched).
   - On **Reject**, the backend records the rejection and nothing is "executed."
5. Every decision — approved or rejected — is appended to a local JSON audit log (`backend/logs/decision_log.json`) and shown in the **Decision Log** panel via `GET /history`.

---

## 📁 Repository Structure

```
mission-hitl-workflow/
├── backend/
│   ├── app.py                 # Flask backend: /analyze, /decision, /history
│   ├── requirements.txt
│   ├── test_scenarios.json    # Sample telemetry payloads
│   └── logs/                  # Simulated audit log (created at runtime, gitignored)
├── docs/
│   ├── prompt.txt             # Prompt used for the Gemini analysis step
│   ├── input_schema.json      # /analyze request shape
│   ├── output_schema.json     # /analyze response shape
│   └── decision_schema.json   # /decision request/response shape
├── frontend/
│   └── index.html             # UI: scenario picker, analysis, approval panel, audit log
├── .gitignore
└── README.md
```

---

## ⚙️ Setup Instructions

### 1. Clone / copy the project and enter the backend folder

```bash
cd mission-hitl-workflow/backend
```

### 2. Create and activate a virtual environment

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS / Linux
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. (Optional) Configure your Gemini API key

Create a `.env` file inside `/backend`:

```env
GEMINI_API_KEY=your_api_key_here
```

> You can also run the whole demo **without** an API key. If `GEMINI_API_KEY` is missing, `/analyze` gracefully falls back to a fixed sample response instead of crashing — see [Notes on the original code](#-notes-on-the-original-code) below. The human-approval workflow (`/decision`, `/history`) works identically either way, since it never depends on the AI call.

### 5. Run the backend server

```bash
python app.py
```

The server runs at: `http://127.0.0.1:5000`

### 6. Open the app

Open your browser at `http://127.0.0.1:5000` (the backend also serves the frontend).

---

## 🎮 Demo Flow

1. Select a scenario: **Thermal Anomaly**, **Energy Anomaly**, or **Communication Loss**.
2. Click **Analyze** → the agent returns a classification, severity, and a **recommended action**.
3. The **Proposed Action** panel appears with the recommended action and two buttons: **✅ Approve** / **❌ Reject**. Nothing happens until you click one.
4. Click **Approve** → the backend logs the decision and returns a simulated confirmation (e.g. *"Simulated cooling/load adjustment applied. No external system was contacted."*).
   Click **Reject** instead → the backend logs the rejection and confirms *"No changes were made."*
5. The **Decision Log** panel refreshes automatically, showing the full audit trail of every decision made so far (executed or rejected), pulled from `GET /history`.

---

## 🔌 API Reference

### `POST /analyze`
Request:
```json
{
  "subsystem": "thermal",
  "metric": "temperature_core",
  "value": 85,
  "mission_phase": "nominal",
  "timestamp": "2026-04-17T12:30:00Z"
}
```
Response:
```json
{
  "classification": "thermal degradation",
  "severity": "high",
  "recommended_action": "reduce load and activate cooling",
  "reasoning": "Temperature exceeds nominal threshold while efficiency is decreasing",
  "requires_approval": true,
  "subsystem": "thermal"
}
```

### `POST /decision`
Request:
```json
{
  "subsystem": "thermal",
  "classification": "thermal degradation",
  "severity": "high",
  "recommended_action": "reduce load and activate cooling",
  "reasoning": "Temperature exceeds nominal threshold while efficiency is decreasing",
  "decision": "approve"
}
```
Response (on approval):
```json
{
  "id": "388e029c-...",
  "timestamp": "2026-08-11T06:28:15.880732+00:00",
  "status": "executed",
  "system_response": "Simulated cooling/load adjustment applied. No external system was contacted. (Action: \"reduce load and activate cooling\")",
  "...": "plus the original classification/severity/recommended_action/reasoning"
}
```
`decision` must be `"approve"` or `"reject"`; anything else returns `400`.

### `GET /history`
Returns the full audit trail (most recent first) — every decision ever recorded, whether executed or rejected.

Full request/response examples for all three endpoints are also in `docs/`.

---

## 🛡 Safety Design

This is the core requirement of the challenge, so it's worth stating explicitly:

- **No email is ever sent.** No SMTP, no third-party mail API.
- **No money is ever spent.** No payment or budget API is called.
- **No real external system is ever modified.** `simulate_action_execution()` only builds and returns a descriptive string.
- The only side effect of an approved action is a new entry in the local JSON audit log — nothing leaves the machine running the demo.

If you want to turn this into a system that performs real actions, the natural extension point is `simulate_action_execution()` in `backend/app.py` — but that step is intentionally out of scope here.

---

## 🔧 Notes on the Original Code (What Was Changed)

Compared to the original `ai-mission-decision-copilot` repository, this extension:

- **Keeps `/analyze` fully backward-compatible** — same request/response shape, plus two additive fields (`requires_approval`, `subsystem`) that the approval UI needs.
- **Fixes a startup bug**: the original code built the Gemini client (`genai.Client(...)`) at import time, which raised an unhandled exception and crashed the whole server if `GEMINI_API_KEY` wasn't set — before Flask even started. The client is now created lazily inside `/analyze`, so a missing key correctly falls back to `FALLBACK_RESPONSE` instead of crashing.
- **Adds `POST /decision`** — the human-approval gate and simulated executor.
- **Adds `GET /history`** — the audit trail.
- **Adds `backend/requirements.txt`** for reproducible installs (previously only documented as a `pip install` command in the README).
- **Fixes `.gitignore`** — the original repository had `backend/venv/` committed to git (~850 tracked files). This version ignores `venv/`, `__pycache__/`, and the runtime `logs/` folder.
- **Removes `frontend/script.js`** — a duplicate, unused copy of the analyze logic that wasn't referenced by `index.html` (the page uses its own inline script). Keeping two divergent copies of the same logic was a likely source of confusion.
- **Rewrites `frontend/index.html`** to add the approval panel and decision log, while keeping the original scenario-picker UX.

---

## ⚠️ Limitations

- No real-time telemetry stream (scenarios are pre-defined test payloads).
- The audit log is a local JSON file, not a database — fine for a demo, not for production.
- No user authentication — anyone with access to the running instance can approve or reject.
- No confidence scoring on the AI's classification.

## 🔮 Possible Future Improvements

- Real telemetry integration.
- Persist the audit log in a proper database.
- Role-based approval (e.g., only certain operators can approve `critical` severity actions).
- Notifications (Slack/email) when an action is awaiting approval — itself gated the same way, or genuinely wired up if that becomes in-scope.

---

## 📄 License

MIT License (same as the original project).
